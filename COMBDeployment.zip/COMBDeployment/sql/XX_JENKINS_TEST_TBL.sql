/********************************************************
***  Script to create table
***
**********************************************************/
DROP TABLE XX_JENKINS_TEST
/

CREATE TABLE XX_JENKINS_TEST
(TEST_ID  NUMBER,
TEST_ID1 NUMBER)
/

